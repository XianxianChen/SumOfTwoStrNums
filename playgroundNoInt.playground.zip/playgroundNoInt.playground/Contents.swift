//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//“You are beta testing the newest version of Xcode and it has a bug. You can no longer use built-in Int function to turn a string into a number. Given this restriction, create a playground with a function that takes two strings of numbers as arguments and returns a new string that is the sum of the arguments.

// Method One: Using Double to convert string into a double.
func sumOfTwoString(strOne: String, strTwo: String) -> String {
    guard let numOne = Double(strOne), let numTwo = Double(strTwo) else {
        return "please enter string of numbers"
    }
    let sum = numOne + numTwo
    var result = String(sum)
    result.removeLast() // remove the "0" after decimal point
    result.removeLast() // remove the decimal point
    return "\(result)"
}
sumOfTwoString(strOne: "12345", strTwo: "543")
sumOfTwoString(strOne: "-23", strTwo: "5")

// Method Two: iterate through the string to get the number

func sumMethodTwo(strOne: String, strTwo: String) -> String {
    var numOne = 0
    var numTwo = 0
    var sOne = strOne
    var sTwo = strTwo
    var num = 0
    while !sOne.isEmpty {
        let char = sOne.removeFirst()
    
        switch char {
        case "0":
            num = 0
        case "1":
            num = 1
        case "2":
            num = 2
        case "3":
            num = 3
        case "4":
            num = 4
        case "5":
            num = 5
        case "6":
            num = 6
        case "7":
            num = 7
        case "8":
            num = 8
        case "9":
            num = 9
        default:
            continue
        }
        numOne = numOne * 10 + num
    }
    while !sTwo.isEmpty {
        let char = sTwo.removeFirst()
        switch char {
        case "0":
            num = 0
        case "1":
            num = 1
        case "2":
            num = 2
        case "3":
            num = 3
        case "4":
            num = 4
        case "5":
            num = 5
        case "6":
            num = 6
        case "7":
            num = 7
        case "8":
            num = 8
        case "9":
            num = 9
        default:
            continue
        }
        numTwo = numTwo * 10 + num
    }
    if strOne.first == "-" {
        numOne = -numOne
    }
    if strTwo.first == "-" {
        numTwo = -numTwo
    }
    let sum = numOne + numTwo
    return "\(sum)"
}

sumMethodTwo(strOne: "11", strTwo: "12")
sumMethodTwo(strOne: "-123", strTwo: "-22")


//Bonus: Your Xcode also lacks the basic operator “+”, find a way to add the two strings together without using basic addition

// Method One
func sumOfTwo(strOne: String, strTwo: String) -> String {
    guard let numOne = Double(strOne), let numTwo = Double(strTwo) else {
        return "please enter string of numbers"
    }
    let sum = numOne - (-numTwo)
    var result = String(sum)
    result.removeLast()
    result.removeLast()
    return "\(result)"
}
sumOfTwo(strOne: "12345", strTwo: "543")
sumOfTwo(strOne: "23", strTwo: "5")

// Method Two
func sumOfTwoMethodTwo(strOne: String, strTwo: String) -> String {
    var numOne = 0
    var numTwo = 0
    var sOne = strOne
    var sTwo = strTwo
    var num = 0
    while !sOne.isEmpty {
        let char = sOne.removeFirst()
        switch char {
        case "0":
            num = 0
        case "1":
            num = 1
        case "2":
            num = 2
        case "3":
            num = 3
        case "4":
            num = 4
        case "5":
            num = 5
        case "6":
            num = 6
        case "7":
            num = 7
        case "8":
            num = 8
        case "9":
            num = 9
        default:
            continue
        }
        numOne = numOne * 10 - ( -num)
    }
    while !sTwo.isEmpty {
        let char = sTwo.removeFirst()
        switch char {
        case "0":
            num = 0
        case "1":
            num = 1
        case "2":
            num = 2
        case "3":
            num = 3
        case "4":
            num = 4
        case "5":
            num = 5
        case "6":
            num = 6
        case "7":
            num = 7
        case "8":
            num = 8
        case "9":
            num = 9
        default:
            continue
        }
        numTwo = numTwo * 10 - ( -num)
    }
    if strOne.first == "-" {
        numOne = -numOne
    }
    if strTwo.first == "-" {
        numTwo = -numTwo
    }
    let sum = numOne - (-numTwo)
    return "\(sum)"
}
sumOfTwoMethodTwo(strOne: "-123", strTwo: "-4")
sumOfTwoMethodTwo(strOne: "11", strTwo: "-9")
